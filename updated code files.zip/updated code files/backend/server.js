const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const xlsx = require("xlsx");

const app = express();
app.use(cors());

// Define path to Docs directory
const docsDir = path.join(__dirname, "Docs");

// Function to ensure proper date formatting without errors
const preserveDateFormat = (value, key) => {
  const dateFields = new Set(["FLD TXN Date", "FLD Post Date", "Repre Date"]); // ✅ Actual date fields

  if (dateFields.has(key) && typeof value === "number" && value > 30000) { // ✅ Excel serial numbers are usually > 30,000
    const excelEpochStart = new Date(1899, 11, 30);
    const formattedDate = new Date(excelEpochStart.getTime() + value * 86400000);

    return !isNaN(formattedDate.getTime()) ? formattedDate.toISOString().split("T")[0] : value; // ✅ Keep YYYY-MM-DD format
  }

  return value; // ✅ Ensure other values (numbers, text) remain unchanged
};

app.get("/api/getClaims", (req, res) => {
  try {
    const files = fs.readdirSync(docsDir).filter(file => file.endsWith(".xlsx"));
    let claimsData = [];

    files.forEach(file => {
      const filePath = path.join(docsDir, file);
      const workbook = xlsx.readFile(filePath, { cellDates: false });

      workbook.SheetNames.forEach(sheetName => {
        const trimmedSheetName = sheetName.trim();
        const sheetData = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName], { raw: true, defval: "" });

        if (sheetData.length > 0) {  // ✅ Process all sheets, no exclusions
          const formattedData = sheetData.map(row => {
            const cleanedRow = {};
            for (const key in row) {
              cleanedRow[key.trim()] = preserveDateFormat(row[key], key.trim());
            }
            return {
              ...cleanedRow,
              sheetName: trimmedSheetName
            };
          });

          claimsData = [...claimsData, ...formattedData];
        }
      });
    });

    console.log("✅ Final Claims Data:", JSON.stringify(claimsData, null, 2)); // Debugging log
    res.json(claimsData);
  } catch (error) {
    console.error("🚨 Server Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));