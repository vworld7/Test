import React, { useEffect } from "react";

export default function NotesDetails({ claimsData, selectedClaim }) {
  // ✅ Debugging: Log claimsData and selectedClaim
  useEffect(() => {
    console.log("✅ Claims Data in NotesDetails:", claimsData);
    console.log("✅ Selected Claim:", selectedClaim);
  }, [claimsData, selectedClaim]);

  // ✅ Retrieve Notes only for the selected Claim Number
  const notesData = claimsData.filter(row => row.sheetName === "Notes" && row["FLD Claim Number"] === selectedClaim);

  return (
    <div className="text-gray-700">
      <h2 className="p-4">📝 Notes Details</h2>
      <table style={{ borderCollapse: "collapse", width: "100%" }}>
        <thead>
          <tr>
            <th style={{ border: "1px solid black", textAlign: "left", padding: "4px", width: "40%" }}>Created Date</th>
            <th style={{ border: "1px solid black", textAlign: "left", padding: "4px", width: "60%" }}>Note Text</th>
            <th style={{ border: "1px solid black", textAlign: "left", padding: "4px", width: "40%" }}>TXN ID</th>

          </tr>
        </thead>
        <tbody>
          {notesData.length > 0 ? (
            notesData.map((note, index) => (
              <tr key={`note-${index}`}>
                <td style={{ border: "1px solid black", padding: "4px", width: "40%" }}>
                  {note["FLD Created Date"] || "N/A"}
                </td>
                <td style={{ border: "1px solid black", padding: "4px", width: "60%" }}>
                  {note["FLD Note Text"] || "N/A"}
                </td>
                <td style={{ border: "1px solid black", padding: "4px", width: "60%" }}>
                  {note["FLD TXN ID"] || "NA"}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="2" style={{ border: "1px solid black", padding: "4px", textAlign: "center" }}>
                ❌ No notes found for the selected claim.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}