import React, { useState, useEffect, useMemo } from "react";

export default function DisputeTable({ claimsData, selectedClaim, setSelectedClaim }) {
  const [checkedStates, setCheckedStates] = useState({});
  const [loading, setLoading] = useState(true);

  const relevantColumns = [
    "FLD Claim Number",
    "TXN Doc ID",
    "FLD TXN Date",
    "FLD Post Date",
    "FLD TXN Amount",
    "Repre Date"
  ];

  useEffect(() => {
    if (claimsData) {
      console.log("✅ Raw claimsData BEFORE filtering in DisputeTable:", JSON.stringify(claimsData, null, 2));
    } else {
      console.warn("⏳ Waiting for API response...");
    }
  }, [claimsData]);

  const filteredData = useMemo(() => (
    claimsData && Array.isArray(claimsData) ? claimsData.filter(row => row.sheetName === "Txn data") : []
  ), [claimsData]);

  useEffect(() => {
    if (filteredData.length > 0) {
      setCheckedStates(filteredData.reduce((acc, item) => ({
        ...acc,
        [item["FLD Claim Number"]]: false
      }), {}));
      setLoading(false);
    }
  }, [filteredData]);

  const handleCheckboxChange = (claimNumber) => {
    setCheckedStates((prevState) => ({
      ...Object.fromEntries(Object.keys(prevState).map(key => [key, false])),
      [claimNumber]: true,
    }));
    setSelectedClaim(claimNumber);
  };

  if (!claimsData) {
    return <p className="text-center text-gray-600">⏳ Loading claims data...</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="table-auto w-full bg-white rounded-lg shadow">
        <thead>
          <tr style={{ backgroundColor: "#D3d3d3", color: "#333", textAlign: "center" }}>
            <th className="p-3 border border-white">Select</th>
            {relevantColumns.map((col) => (
              <th key={col} className="p-3 border border-white">{col}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {loading ? (
            <tr>
              <td colSpan={relevantColumns.length + 1} className="text-center p-3">
                🔄 Loading claims data...
              </td>
            </tr>
          ) : filteredData.length === 0 ? (
            <tr>
              <td colSpan={relevantColumns.length + 1} className="text-center p-3">
                ❌ No claims found from "Txn data" sheet.
              </td>
            </tr>
          ) : (
            filteredData.map((item, index) => (
              <tr key={item["FLD Claim Number"] || `row-${index}`}
                  className={`text-sm ${index % 2 === 0 ? "bg-gray-100" : "bg-white"}`}
                  style={{ textAlign: "center" }}>
                <td className="p-3 border border-white">
                  <input
                    type="checkbox"
                    name="selectedClaim"
                    value={item["FLD Claim Number"]}
                    checked={checkedStates[item["FLD Claim Number"]]}
                    onChange={() => handleCheckboxChange(item["FLD Claim Number"])}
                    className="cursor-pointer"
                  />
                </td>
                {relevantColumns.map((col) => (
                  <td key={col} className="p-3 border border-white">
                    {item[col] !== undefined ? item[col] : "N/A"}  {/* ✅ Preserve original formatting */}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}