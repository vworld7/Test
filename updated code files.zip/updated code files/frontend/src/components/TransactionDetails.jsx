import React, { useEffect } from "react";

export default function TransactionDetails({ claimsData, selectedClaim }) {
  // Debugging: Log claimsData and selectedClaim when they update
  useEffect(() => {
    console.log("✅ Selected Claim:", selectedClaim);
    console.log("✅ Claims Data in TransactionDetails:", claimsData);
  }, [claimsData, selectedClaim]);

  // ✅ Find the transaction matching the selected claim
  const txnData = claimsData.find(row => row.sheetName === "Txn data" && row["FLD Claim Number"] === selectedClaim);

  return (
    <div className="text-gray-700">
      <h2 className="p-4">📜 Transaction Details</h2>
      <table style={{ borderCollapse: "collapse", width: "100%" }}>
        <thead>
          <tr>
            <th style={{ border: "1px solid black", textAlign: "left", padding: "4px", width: "40%" }}>Field</th>
            <th style={{ border: "1px solid black", textAlign: "left", padding: "4px", width: "60%" }}>Value</th>
          </tr>
        </thead>
        <tbody>
          {txnData ? (
            <>
              <tr>
                <td style={{ border: "1px solid black", padding: "4px", width: "40%" }}>Txn ID</td>
                <td style={{ border: "1px solid black", padding: "4px", width: "60%" }}>{txnData["TXN Doc ID"] || "N/A"}</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid black", padding: "4px", width: "40%" }}>Notification Date</td>
                <td style={{ border: "1px solid black", padding: "4px", width: "60%" }}>{txnData["FLD CH Notification Date"] || "N/A"}</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid black", padding: "4px", width: "40%" }}>Disputed Amount</td>
                <td style={{ border: "1px solid black", padding: "4px", width: "60%" }}>${txnData["Disputed TXN Amount"] || "N/A"}</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid black", padding: "4px", width: "40%" }}>Network</td>
                <td style={{ border: "1px solid black", padding: "4px", width: "60%" }}>{txnData["FLD Network ID"] || "N/A"} (Visa)</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid black", padding: "4px", width: "40%" }}>CB Date</td>
                <td style={{ border: "1px solid black", padding: "4px", width: "60%" }}>{txnData["FLD Chargeback Date"] || "N/A"}</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid black", padding: "4px", width: "40%" }}>CB Reason code</td>
                <td style={{ border: "1px solid black", padding: "4px", width: "60%" }}>
                  {txnData["CB Reason Code"] || "N/A"} ({txnData["Disp Cat Con"] || "N/A"})
                </td>
              </tr>
              <tr>
                <td style={{ border: "1px solid black", padding: "4px", width: "40%" }}>MCC</td>
                <td style={{ border: "1px solid black", padding: "4px", width: "60%" }}>{txnData["FLD Merchant Category Code"] || "N/A"}</td>
              </tr>
              <tr>
                <td style={{ border: "1px solid black", padding: "4px", width: "40%" }}>Merchant Name</td>
                <td style={{ border: "1px solid black", padding: "4px", width: "60%" }}>{txnData["FLD Merchant Name"] || "N/A"}</td>
              </tr>
            </>
          ) : (
            <tr>
              <td colSpan="2" style={{ border: "1px solid black", padding: "4px", textAlign: "center" }}>
                ❌ No transaction data found for the selected claim.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}