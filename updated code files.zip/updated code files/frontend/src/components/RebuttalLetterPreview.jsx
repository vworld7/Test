import React, { useEffect } from "react";

export default function TransactionDetails({ selectedClaim }) {
  // Debugging: Log claimsData and selectedClaim when they update
  useEffect(() => {
    console.log("✅ Selected Claim:", selectedClaim);
  }, [selectedClaim]);


  return (
    <div className="p-6 text-gray-800 border rounded-lg bg-white shadow">
      {selectedClaim === "D1111111261" ? (
        <>
          <p className="text-right">04/29/2025</p>
          <br />
          <p>Dear Jason Jones:</p>
          <br />
          <p className="leading-relaxed">
            Thank you for your recent inquiry regarding the transaction(s) noted on the last page of this letter.
          </p>
          <br />
          <p className="leading-relaxed">
            You received provisional credit for this transaction in the amount of <strong>$25.54</strong>.
          </p>
          <br />
          <p className="leading-relaxed text-blue-500">
            The merchant has provided information concerning your claim: Merchant has responded to your dispute and is
            stating that the merchandise was delivered. Please review the merchant's documentation. However, if the merchandise
            was received and returned, please state the specific reason for the return. In order to intercede on your behalf,
            card regulations require proof of return (return receipt and tracking number, proof that merchant has signed for
            returned items) and proof the merchandise was received by the merchant. If you have been in contact with the
            merchant, please provide the dates of contact and response from merchant.
          </p>
          <br />
          <ol className="list-decimal pl-5">
            <li className="leading-relaxed">
              Please notify us if you have concerns with the information provided by the merchant. If you have additional
              documentation that supports your claim, please provide it with your response. You may contact us at the phone
              number listed above or notify us in writing by mail or fax. Please use a copy of this letter as your coversheet
              if notifying by mail or fax.
            </li>
            <br />
            <li className="leading-relaxed">
              If you agree that this is a valid charge, please notify our office referencing your claim number by{" "}
              <strong>05/09/2025</strong>, at <strong>(800) 600-5249</strong> to confirm the charge.
            </li>
          </ol>
          <br />
          <p className="leading-relaxed">
            If a response is not received by <strong>05/09/2025</strong>, we will conclude our investigation and make a
            decision on your claim based on the information that we currently have available.
          </p>
          <br />
          <p className="leading-relaxed">
            Please retain a copy of this letter and all documentation relative to your claim for your records. If you have any
            additional questions, please contact us and reference your claim number. We appreciate the opportunity to be of
            service.
          </p>
          <br />
          <p>Sincerely,</p>
          <p>Chargeback Services</p>
          <br />
          <h4 className="font-bold">Transaction Details:</h4>
          <table className="border-collapse border border-gray-300 w-full text-left mt-4">
            <thead>
              <tr>
                <th className="border border-gray-300 px-2 py-1">Txn Date</th>
                <th className="border border-gray-300 px-2 py-1">Merchant Name</th>
                <th className="border border-gray-300 px-2 py-1">Txn Amount</th>
                <th className="border border-gray-300 px-2 py-1">Txn ID</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-300 px-2 py-1">02/20/2025</td>
                <td className="border border-gray-300 px-2 py-1">TODAY SHOPS</td>
                <td className="border border-gray-300 px-2 py-1">$25.54</td>
                <td className="border border-gray-300 px-2 py-1">222222292</td>
              </tr>
            </tbody>
          </table>
        </>
      ) : (
        <div className="text-left text-gray-500 py-8">
          No rebuttal letter required for this claim.
        </div>
      )}
    </div>
  );
}