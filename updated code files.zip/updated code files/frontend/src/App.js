import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import DisputeTable from "./components/DisputeTable";
import TransactionDetails from "./components/TransactionDetails";
import NotesDetails from "./components/NotesDetails";
import RebuttalLetterPreview from "./components/RebuttalLetterPreview";
import disputeResponsePDF from "./Docs/DisputeResponse.pdf";
import FeedbackTable from "./components/FeedbackTable";
import { FaFilePdf } from "react-icons/fa";
import DynamicTable from "./components/DynamicTable";
import { FaThumbsUp, FaThumbsDown } from "react-icons/fa"; // Importing icons
//const [txnData, setTxnData] = useState(null);

export default function App() {
  const [selectedClaim, setSelectedClaim] = useState(null); // Track selected claim
  const [activeTab, setActiveTab] = useState("Dashboard"); // Track current main tab
  const [activeExecutionSubTab, setActiveExecutionSubTab] = useState("Transaction Details"); // Default Execution sub-tab
  const [isExecutionEnabled, setIsExecutionEnabled] = useState(false); // Disable tabs initially
  const [isFeedbackEnabled, setIsFeedbackEnabled] = useState(false); // Disable feedback tab initially
  const [agents] = useState(["Claim Validation Agent", "Regulatory Agent", "Decision Agent", "Validator Agent"]); // Agent names
  const [progressStates, setProgressStates] = useState(agents.map(() => 0)); // Agent progress
  const [isProcessing, setIsProcessing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [claimsData, setClaimsData] = useState(null); // ✅ Start with null instead of empty array
  const [claimvalidationResponse, setClaimvalidationResponse] = useState(null);
  const [regulatoryAgentResponse, setRegulatoryAgentResponse] = useState(null); // To store RegulatoryAgent response
  const [cbvalidationdisplayResponse, setCBValidationDisplayResponse] = useState(null); // To store RegulatoryAgent response
  const [decisionResponse, setDecisionResponse] = useState(null);
  const [validatorResponse, setValidatorResponse] = useState(null);
  const [summarizerResponse, setSummarizerResponse] = useState(null);
  const [feedback, setFeedback] = useState(Array(10).fill(null));
  const [pdfUrl, setPdfUrl] = useState(null);
  const [pdfError, setPdfError] = useState(null);
  //const [txnData, setTxnData] = useState(null);
  const [lastRunTime, setLastRunTime] = useState(null);
  const [claimProgressStates, setClaimProgressStates] = useState({}); // Track progress for multiple claims
  const [claimRunTimes, setClaimRunTimes] = useState({}); // Track last run time for each claim
  const [processedClaims, setProcessedClaims] = useState([]); // Track which claims have been processed
  const [isCompleted, setIsCompleted] = useState(false);
  const [completedClaims, setCompletedClaims] = useState({});
    // ✅ Place useEffect HERE, outside any functions, so it runs when App mounts
  useEffect(() => {
  const fetchData = async () => {
    try {
      const response = await fetch("http://localhost:5001/api/getClaims", {
        method: "GET",
        headers: { "Content-Type": "application/json" }
      });

      if (!response.ok) {
        throw new Error(`API call failed with status ${response.status}`);
      }

      const data = await response.json();
      console.log("✅ API Data Received:", JSON.stringify(data, null, 2)); // Debugging log

      if (Array.isArray(data) && data.length > 0) {
        setClaimsData(data);
      } else {
        console.warn("🚨 No data received from API!");
        setClaimsData([]);
      }
    } catch (error) {
      console.error("🚨 Error fetching API:", error);
    }
  };

  fetchData();
}, []);

// New useEffect for handling claim selection
useEffect(() => {
  if (window.progressInterval) {
    clearInterval(window.progressInterval);
    window.progressInterval = null;
  }

  // Reset progress states when a new claim is selected
  setProgressStates(agents.map(() => 0));
  setIsProcessing(false);
  setIsCompleted(false); // Add this line

  return () => {
    if (window.progressInterval) {
      clearInterval(window.progressInterval);
      window.progressInterval = null;
    }
  };
}, [selectedClaim]);

  // Check if all progress bars are 100% and enable tabs
  useEffect(() => {
    const allBarsCompleted = progressStates.every((progress) => progress === 100);
    setIsExecutionEnabled(allBarsCompleted); // Enable Execution tab
    setIsFeedbackEnabled(allBarsCompleted); // Enable Feedback tab
  }, [progressStates]);


  // Render content for the Main Page tab
  const renderContentForMainPage = () => {
  return (
    <div>
       {/* Header Section */}
<div className="flex justify-between items-center mb-4">
  <h1 className="text-2xl font-bold">Dispute Claims</h1>
  <button
    className="px-4 py-1 rounded transition-colors duration-200"
    style={{
      backgroundColor: "#808080",
      color: "#FFF",
      cursor: "pointer",
    }}
    onMouseEnter={(e) => {
      e.target.style.backgroundColor = "#E6F2E6";
      e.target.style.color = "#000";
    }}
    onMouseLeave={(e) => {
      e.target.style.backgroundColor = "#808080";
      e.target.style.color = "#FFF";
    }}
    onClick={handleRefresh}
  >
    Refresh
  </button>
</div>

      {/* Claims Table */}
      <DisputeTable
        claimsData={claimsData}
        selectedClaim={selectedClaim}
        setSelectedClaim={(claim) => {
          setSelectedClaim(claim);
          setProgressStates(agents.map(() => 0));
          setIsProcessing(false);
        }}
      />

      {/* Action Button Section */}
      <div className="mt-4">
        {selectedClaim ? (
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button
              className="mt-4 px-4 py-2 rounded"
              style={{
                backgroundColor: "#808080",
                color: selectedClaim && !isProcessing ? "#FFF" : "#BBB",
                cursor: !selectedClaim || isProcessing ? "not-allowed" : "pointer",
              }}
              onMouseEnter={(e) => {
                if (selectedClaim && !isProcessing) {
                  e.target.style.backgroundColor = "#E6F2E6";
                  e.target.style.color = "#000";
                }
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = "#808080";
                e.target.style.color = "#FFF";
              }}
              disabled={!selectedClaim || isProcessing}
              onClick={triggerAgentSimulation}
            >
              {isProcessing ? "Processing..." : "Initiate Review Process"}
            </button>
          </div>
        ) : (
          <p className="text-gray-500">Please select a claim to process.</p>
        )}
      </div>

      {/* Combined Progress Section */}
      {/* Combined Progress Section */}
<div className="mt-6">
  <h2 className="text-xl font-semibold mb-4">Progress Tracking</h2>
  <div className="bg-white rounded-lg shadow">
    {/* Headers */}
    <div className="grid grid-cols-6 gap-4 bg-gray-50 p-4 rounded-t-lg border-b">
      <div className="font-bold text-center">Claim ID</div>
      {agents.map((agent) => (
        <div key={agent} className="font-bold text-center">
          {agent.replace('Agent', '').trim()}
        </div>
      ))}
      <div className="font-bold text-center">Status</div>
    </div>

    {/* Content */}
    <div className="divide-y">
      {/* Current Selected Claim (if any) */}
      {selectedClaim && (
        <div className="grid grid-cols-6 gap-4 p-4 bg-gray-50">
          <div className="text-center font-medium">{selectedClaim}</div>
          {agents.map((_, index) => (
            <div key={`current-${index}`} className="w-full">
              <div className="relative bg-gray-200 h-4 w-full rounded">
                <div
                  className="absolute bg-green-500 h-4 rounded transition-all duration-300 ease-in-out"
                  style={{ width: `${progressStates[index]}%` }}
                ></div>
              </div>
              <p className="text-center mt-1 text-sm">{progressStates[index]}%</p>
            </div>
          ))}
          <div className="text-center text-sm text-gray-600">
            {(() => {
              if (isProcessing) return 'In Progress...';
              if (completedClaims[selectedClaim]) return 'Completed';
              return 'Not started';
            })()}
          </div>
        </div>
      )}

      {/* Previously Processed Claims */}
      {processedClaims
        .filter(claimId => claimId !== selectedClaim)
        .map((claimId) => (
          <div key={claimId} className="grid grid-cols-6 gap-4 p-4">
            <div className="text-center font-medium">{claimId}</div>
            {agents.map((_, index) => (
              <div key={`${claimId}-${index}`} className="w-full">
                <div className="relative bg-gray-200 h-4 w-full rounded">
                  <div
                    className="absolute bg-green-500 h-4 rounded"
                    style={{
                      width: `${(claimProgressStates[claimId]?.[index] || 0)}%`
                    }}
                  ></div>
                </div>
                <p className="text-center mt-1 text-sm">
                  {claimProgressStates[claimId]?.[index] || 0}%
                </p>
              </div>
            ))}
            <div className="text-center text-sm text-gray-600">
              {completedClaims[claimId] ? 'Completed' :
               claimRunTimes[claimId] ? `Last Run: ${claimRunTimes[claimId]}` :
               'Not started'}
            </div>
          </div>
        ))}

      {!selectedClaim && processedClaims.length === 0 && (
        <div className="text-center text-gray-500 py-8">
          No claims have been processed yet
        </div>
      )}
    </div>
  </div>
</div>
    </div>
  );
};

  const handleFeedback = (index, value) => {
    const updatedFeedback = [...feedback];
    updatedFeedback[index] = value;
    setFeedback(updatedFeedback);
  };

  const handleSubmit = () => {
    console.log("Submitted feedback:", feedback);
    alert("Feedback submitted!");
  };

  const handleCancel = () => {
    setFeedback(Array(10).fill(null));
  };

  // Simulate agent progress sequentially
  const triggerAgentSimulation = async () => {
  if (!selectedClaim) {
    alert("Please select a claim to trigger the AI Agent.");
    return;
  }

  // Initialize progress state for this claim if it doesn't exist
  setClaimProgressStates(prev => ({
    ...prev,
    [selectedClaim]: agents.map(() => 0)
  }));

  setIsProcessing(true);
  setLoading(true);
  setError(null);

  try {
    // Simulate progress while calling the backend API
    await simulateSequentialProgress(selectedClaim, agents);

    const response = await fetch("http://localhost:5000/api/validate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ claim_id: selectedClaim }),
    });

    if (!response.ok) {
      throw new Error(`API call failed with status ${response.status}`);
    }

    const data = await response.json();
    console.log("✅ API Call Success:", data);

    if (data.success) {
      const currentTime = new Date().toLocaleString();

      // Update run time for this claim
      setClaimRunTimes(prev => ({
        ...prev,
        [selectedClaim]: currentTime
      }));

      // Add to processed claims if not already there
      setProcessedClaims(prev =>
        prev.includes(selectedClaim) ? prev : [...prev, selectedClaim]
      );

      setClaimvalidationResponse(data.result.ClaimValidationAgent);
      setRegulatoryAgentResponse(data.result.RegulatoryAgent);
      setCBValidationDisplayResponse(data.result.CBValidationDisplayAgent);
      setDecisionResponse(data.result.DecisionAgent);
      setValidatorResponse(data.result.ValidatorAgent);
      setSummarizerResponse(data.result.SummarizerAgent);
    } else {
      throw new Error(data.error || "Unknown error from API");
    }
  } catch (err) {
    console.error(err);
    setError(err.message || "An error occurred while fetching data.");
  } finally {
    setIsProcessing(false);
    setLoading(false);
  }
};

  const simulateSequentialProgress = (claimId, agentIds) => {
  return new Promise((resolve) => {
    let agentIndex = 0;

    const processAgent = () => {
      if (agentIndex >= agentIds.length) {
        setIsProcessing(false);
        // Update completed claims
        setCompletedClaims(prev => ({
          ...prev,
          [claimId]: true
        }));
        resolve();
        return;
      }

      const currentAgentIndex = agentIndex;
      let progressValue = 0;

      const simulateProgress = async () => {
        while (progressValue < 100) {
          const randomDelay = Math.random() * 800 + 200;
          await new Promise((resolve) => setTimeout(resolve, randomDelay));

          const increment = Math.floor(Math.random() * 10 + 5);
          progressValue = Math.min(progressValue + increment, 100);

          setProgressStates(prev => {
            const newProgress = [...prev];
            newProgress[currentAgentIndex] = progressValue;
            return newProgress;
          });

          setClaimProgressStates(prev => ({
            ...prev,
            [claimId]: (prev[claimId] || agents.map(() => 0)).map((p, idx) =>
              idx === currentAgentIndex ? progressValue : p
            )
          }));
        }
        agentIndex++;
        processAgent();
      };

      simulateProgress();
    };

    processAgent();
  });
};

  const handleRefresh = async () => {
  try {
    if (window.progressInterval) {
      clearInterval(window.progressInterval);
      window.progressInterval = null;
    }

    // Reset all states to initial values
    setSelectedClaim(null);
    setProgressStates(agents.map(() => 0));
    setIsProcessing(false);
    setCompletedClaims({}); // Reset completed claims
    setClaimProgressStates({});
    setProcessedClaims([]);
    setClaimRunTimes({});

    // Rest of your existing refresh logic...
  } catch (error) {
    console.error("🚨 Error fetching API:", error);
    setClaimsData([]);
  }
};

  // Render content for the Execution tab
  const renderContentForExecutionTab = () => {
    const executionTabs = ["Transaction Details", "Notes", "Document Interpretation" , "CB Validation", "Compelling Evidence", "Rebuttal Letter Preview", "Agents Playground"];
    const renderExecutionContent = () => {
      switch (activeExecutionSubTab) {
        case "Transaction Details":
          return ( <TransactionDetails claimsData={claimsData} selectedClaim={selectedClaim}  /> );

        case "Notes":
          return ( <NotesDetails claimsData={claimsData} selectedClaim={selectedClaim} /> );

        case "Rebuttal Letter Preview":
            return ( <RebuttalLetterPreview selectedClaim={selectedClaim} /> );



        case "Document Interpretation":
  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold mb-4">Document Interpretation</h2>
      {selectedClaim ? (
        <div>
          <p className="mb-4">Document for Claim ID: {selectedClaim}</p>
          {(() => {
            try {
              require(`./Docs/${selectedClaim}.pdf`);
              return (
                <div className="flex items-center">
                  <a
                    href={`/Docs/${selectedClaim}.pdf`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center space-x-2 hover:text-blue-600 cursor-pointer"
                  >
                    <FaFilePdf className="text-red-500 text-3xl group-hover:text-red-600" />
                    <span className="text-gray-600 group-hover:text-blue-600">
                      View Document
                    </span>
                  </a>
                </div>
              );
            } catch (e) {
              return (
                <div className="flex items-center text-gray-500">
                  <FaFilePdf className="text-gray-400 text-3xl mr-2" />
                  <span>No document available for this claim.</span>
                </div>
              );
            }
          })()}
        </div>
      ) : (
        <p className="text-gray-500">
          Please select a claim to view its documentation.
        </p>
      )}
    </div>
  );

        case "Compelling Evidence":
        return (
  <div className="text-gray-700">
    <table style={{ borderCollapse: 'collapse', width: '70%' }}>
      <thead>
        <tr>
          <th style={{ border: '1px solid black', textAlign: 'left', padding: '8px' }}>Field</th>
          <th style={{ border: '1px solid black', textAlign: 'left', padding: '8px' }}>Value</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td style={{ border: '1px solid black', padding: '8px' }}>Represented timely</td>
          <td style={{ border: '1px solid black', padding: '8px' }}>Yes</td>
        </tr>
        <tr>
          <td style={{ border: '1px solid black', padding: '8px' }}>Compelling evidence addresses the reason for chargeback</td>
          <td style={{ border: '1px solid black', padding: '8px' }}>Yes</td>
        </tr>
        <tr>
          <td style={{ border: '1px solid black', padding: '8px' }}>Compelling evidence addresses the Amount of chargeback</td>
          <td style={{ border: '1px solid black', padding: '8px' }}>Yes</td>
        </tr>
        <tr>
          <td style={{ border: '1px solid black', padding: '8px' }}>Merchant Issued Credit</td>
          <td style={{ border: '1px solid black', padding: '8px' }}>Not found</td>
        </tr>
        <tr>
          <td style={{ border: '1px solid black', padding: '8px' }}>Valid Charge Identification</td>
          <td style={{ border: '1px solid black', padding: '8px' }}>Not found</td>
        </tr>
        <tr>
          <td style={{ border: '1px solid black', padding: '8px' }}>Summary</td>
          <td style={{ border: '1px solid black', padding: '8px' }}>Delivery details match. Date of delivery is after Expected date, send the merchant received information to Cardholder for review</td>
        </tr>
        <tr>
          <td style={{ border: '1px solid black', padding: '8px' }}>Recommendation</td>
          <td style={{ border: '1px solid black', padding: '8px' }}>Rebuttal letter to Cardholder, attach Merchant response received</td>
        </tr>
      </tbody>
    </table>
  </div>
);

        case "CB Validation":
  if (loading) {
    return <p className="text-blue-500">Loading AI Assistance...</p>;
  }
  if (error) {
    return <p className="text-red-500">Error: {error}</p>;
  }

  let parsedResponse = null;
  let cleaned = cbvalidationdisplayResponse;

  if (typeof cleaned === "string") {
    cleaned = cleaned.trim();
    if (cleaned.startsWith("```")) {
      cleaned = cleaned.replace(/```json|```/g, "").trim();
    }

    try {
      parsedResponse = JSON.parse(cleaned);
    } catch (e) {
      return (
        <p className="text-red-500">
          Invalid JSON format: {e.message}
        </p>
      );
    }
  } else {
    parsedResponse = cleaned;
  }

  const renderKeyValue = (obj) =>
    Object.entries(obj).map(([key, value], index) => (
      <div key={index} className="grid grid-cols-1 gap-4 border-b py-2 text-sm">
        <div className="font-medium text-gray-700">{key}</div>
        <div className="col-span-2 text-gray-900">
          {Array.isArray(value)
? value.map((item, i) => <div key={i}>- {item}</div>)
            : typeof value === "object" && value !== null
            ? renderKeyValue(value)
            : value?.toString()}
        </div>
      </div>
    ));

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-6 text-gray-500">CB Validation</h1>
      <div className="bg-white shadow rounded-lg p-4 space-y-2">
        {parsedResponse ? (
          Object.entries(parsedResponse).map(([section, content], index) => (
            <div key={index}>
              <h2 className="text-lg font-semibold text-gray-800 mb-2 capitalize">
                {section.replace(/_/g, " ")}
              </h2>
              <div className="bg-gray-50 border rounded-md p-3">
                {typeof content === "object"
                  ? renderKeyValue(
                      Array.isArray(content)
                        ? Object.fromEntries(
content.map((val) => [val])
                          )
                        : content
                    )
                  : content.toString()}
              </div>
            </div>
          ))
        ) : (
          <p className="text-gray-500">
            AI is validating the final results. Please wait...
          </p>
        )}
      </div>
    </div>
  );

  // All agent responses
  case "Agents Playground":
  if (loading) {
    return <p className="text-blue-500">Loading AI Assistance...</p>;
  }
  if (error) {
    return <p className="text-red-500">Error: {error}</p>;
  }

  // All agent responses
  //const agentResponses = {
    //ClaimValidationAgent: claimvalidationResponse,
    //RegulatoryAgent: regulatoryAgentResponse,
    //DecisionAgent: decisionResponse,
    //ValidatorAgent: validatorResponse,
  //};

  return (
  <div>
    <h1 className="text-2xl font-bold mb-6 text-gray-800">Agent Responses</h1>

    {[
      { title: "ClaimValidationAgent Response", data: claimvalidationResponse },
      { title: "RegulatoryAgent Response", data: regulatoryAgentResponse },
      { title: "DecisionAgent Response", data: decisionResponse },
      { title: "ValidatorAgent Response", data: validatorResponse },
      { title: "SummarizerAgent Response", data: summarizerResponse },
    ].map(({ title, data }, index) => (
      <div key={index} className="mb-6 p-4 bg-gray-100 rounded-md shadow-md">
        {/* Agent Title */}
        <h2 className="text-lg font-bold mb-2">{title}:</h2>

        {/* Render Agent Data */}
        {data ? (
          Array.isArray(data) || typeof data === "object" ? (
            <pre className="bg-white p-4 rounded-md overflow-auto border border-gray-300">
              {JSON.stringify(data, null, 2)}
            </pre>
          ) : (
            <pre
              className="bg-white p-4 rounded-md overflow-auto border border-gray-300 whitespace-pre-line"
            >
              {data}
            </pre>
          )
        ) : (
          <p className="text-gray-500">No data available.</p>
        )}
      </div>
    ))}
  </div>
);
        default:
          return null;
      }
    };

    return (
      <div>
        <h1 className="text-2xl font-bold mb-4">AI Summary</h1>
      {summarizerResponse ? (
        <pre className="bg-gray-100 p-4 rounded-md overflow-auto">
          {summarizerResponse}
        </pre>
      ) : (
        <p className="text-gray-500">AI is validating the final results. Please wait...</p>
      )}

        <div className="flex border-b-2 border-gray-300 mb-4">
          {executionTabs.map((tab) => (
            <button
              key={tab}
            onClick={() => setActiveExecutionSubTab(tab)} // Update active tab
            style={{
              backgroundColor: activeExecutionSubTab === tab ? "#d4edda" : "#f8f9fa", // Active tab: #d4edda; Inactive tab: #f8f9fa (light gray)
              color: activeExecutionSubTab === tab ? "#155724" : "#333", // Active: Dark green text; Inactive: Default text
              borderRadius: "4px 4px 0 0", // Rounded top corners
              padding: "8px 12px",
              marginRight: "8px",
              transition: "background-color 0.2s ease",
              border: "1px solid #ced4da",
            }}

          >
            {tab}
          </button>
          ))}
        </div>
        <div className="mt-4">{renderExecutionContent()}</div>
      </div>
    );
  };

  // Render content for the Feedback tab
  const renderContentForFeedbackTab = () => {

  return (
    <div>
      <FeedbackTable />
    </div>
  );
};


  // Render content based on the active tab
  const renderAppContent = () => {
    switch (activeTab) {
      case "Dashboard":
        return renderContentForMainPage();
      case "Execution":
        return renderContentForExecutionTab();
      case "Feedback":
        return renderContentForFeedbackTab();
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen">
      <Sidebar />
      <div className="flex-1 p-6">
        <div className="tabs border-b-2 mb-4">
          <button
            className={`mr-4 px-4 py-2 ${
              activeTab === "Dashboard" ? "border-b-2 font-bold text-gray-500" : "text-gray-500"
            }`}
            onClick={() => setActiveTab("Dashboard")}
          >
            Dashboard
          </button>
          <button
            className={`mr-4 px-4 py-2 ${
              activeTab === "Execution" && isExecutionEnabled
                ? "border-b-2 font-bold text-gray-500"
                : "text-gray-500"
            }`}
            disabled={!isExecutionEnabled}
            title={
         !isExecutionEnabled
           ? "Complete all agent progress before accessing this tab."
           : "Go to Dashboard tab."
            }

            onClick={() => setActiveTab("Execution")}
          >
            Execution
          </button>
          <button
            className={`mr-4 px-4 py-2 ${
              activeTab === "Feedback" && isFeedbackEnabled
                ? "border-b-2 font-bold text-gray-500"
                : "text-gray-500"
            }`}
            disabled={!isFeedbackEnabled}
            title={
         !isExecutionEnabled
           ? "Complete all agent progress before accessing this tab."
           : "Go to Dashboard tab."
            }
            onClick={() => setActiveTab("Feedback")}
          >
            Feedback
          </button>
        </div>
        {renderAppContent()}
      </div>
    </div>
  );
}